package model;

import java.io.Serializable;

public class Img implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String imgName;
	private String imgAddress;
	private String imgTime;
	private String username;
	public Img(int id, String imgName, String imgAddress, String imgTime,
			String username) {
		super();
		this.id = id;
		this.imgName = imgName;
		this.imgAddress = imgAddress;
		this.imgTime = imgTime;
		this.username = username;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImgName() {
		return imgName;
	}
	public void setImgName(String imgName) {
		this.imgName = imgName;
	}
	public String getImgAddress() {
		return imgAddress;
	}
	public void setImgAddress(String imgAddress) {
		this.imgAddress = imgAddress;
	}
	public String getImgTime() {
		return imgTime;
	}
	public void setImgTime(String imgTime) {
		this.imgTime = imgTime;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
}
