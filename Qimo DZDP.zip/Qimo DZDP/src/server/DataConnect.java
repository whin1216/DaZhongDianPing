package server;

import java.sql.*;

public class DataConnect {

	private static Statement stat;
	private static void init() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver") ; 
		String url="jdbc:mysql://10.52.38.139:3306/qimo";
		String user="root";
		String password="123";
		Connection con = DriverManager.getConnection(url,user,password);
		stat = con.createStatement();
		
	}
	public static Statement getStat() throws ClassNotFoundException, SQLException{
		if(stat==null) init();
		return stat;
	}
}
