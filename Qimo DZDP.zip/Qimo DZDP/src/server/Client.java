package server;

import java.io.*;
import java.net.*;

import java.util.ArrayList;

import model.Img;
import model.User;


public class Client implements ImgProtocal {

	private static Socket s;
	private static ObjectOutputStream oos;
	private static ObjectInputStream ois;

	private static void init() throws UnknownHostException, IOException {
		s = new Socket("10.53.44.22", 1017);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
	}

	public static User login(String username, String password) throws UnknownHostException,
			IOException, ClassNotFoundException {
	
			init();
		oos.writeInt(LOGIN);
		oos.flush();
		oos.writeUTF(username);
		oos.flush();
		oos.writeUTF(password);
		oos.flush();
		User u = (User) ois.readObject();
		return u;
	}
	
	public static void upload(String username,String fname,File file) throws IOException{
		init();
		oos.writeInt(UPLOAD);
		oos.flush();
		oos.writeUTF(username);
		oos.flush();
		oos.writeUTF(fname);
		oos.flush();
		
		FileInputStream fis = new FileInputStream(file);
		byte in[] = new byte[1024];
		OutputStream os = s.getOutputStream();
		int len=0;
		while((len=fis.read(in))!=-1){
			os.write(in,0,len);
		}
		s.shutdownOutput();
	}
	
	public static void download(int id,String filename) throws IOException{
		init();
		oos.writeInt(DOWNLOAD);
		oos.flush();
		oos.writeInt(id);
		oos.flush();
		File f = new File(filename);
		FileOutputStream fos = new FileOutputStream(f);
		byte in[] = new byte[1024];
		InputStream is = s.getInputStream();
		int len=0;
		while((len=is.read(in))!=-1){
			fos.write(in,0,len);
		}	
		fos.close();		
	}
	
	@SuppressWarnings("unchecked")
	public static ArrayList<Img> viewallimg() throws UnknownHostException, IOException, ClassNotFoundException{
		init();
		oos.writeInt(VIEWALLIMG);
		oos.flush();
		ArrayList<Img> imgs = (ArrayList<Img>) ois.readObject();
		return imgs;
		
	}
	//public void viewimg(int id){
		
	//}
	
}
