package server;

public interface ImgProtocal {

	int LOGIN = 1001;
	int UPLOAD = 1002;
	int DOWNLOAD = 1003;
	int VIEWALLIMG = 1004;
	int VIEWIMG = 1005;
}
