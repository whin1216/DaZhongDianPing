package server;

import java.io.*;
import java.net.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Img;
import model.User;

public class Server implements ImgProtocal ,Runnable{

	private Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	ServerSocket ss;

	public Server() throws IOException, SQLException, ClassNotFoundException {
		ss = new ServerSocket(1017);
		Thread t = new Thread(this);
		t.start();
	}

	public void login() throws UnknownHostException, IOException,
			ClassNotFoundException, SQLException {

		String username = ois.readUTF();
		String password = ois.readUTF();
		User u = null;
		String sql = "select * from user where username='" + username
				+ "' and password = '" + password + "'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if (rs.next()) {
			u = new User(username, password);
		}
		// System.out.println(a);
		oos.writeObject(u);
		oos.flush();
	}

	public void upload() throws IOException, SQLException,
			ClassNotFoundException {
		String username = ois.readUTF();
		String fname = ois.readUTF();

		File f = new File("c:/" + username + "/" + fname + ".jpg");
		f.getParentFile().mkdirs();
		FileOutputStream fos = new FileOutputStream(f);
		byte in[] = new byte[1024];
		InputStream is = s.getInputStream();
		int len = 0;
		while ((len = is.read(in)) != -1) {
			fos.write(in, 0, len);
		}
		fos.close();

		String sql = "insert into img (username,imgaddress,imgname) values('"
				+ username + "','C:/" + username + "','" + fname + "')";
		DataConnect.getStat().executeUpdate(sql);
	}

	public void download() throws IOException, SQLException,
			ClassNotFoundException {
		int id = ois.readInt();

		String sql = "select * from img where id=" + id;
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if (rs.next()) {
			String fname = rs.getString("imgaddress") + "/"
					+ rs.getString("imgname")+".jpg";
			File f = new File(fname);
			FileInputStream fis = new FileInputStream(f);
			byte in[] = new byte[1024];
			OutputStream os = s.getOutputStream();
			int len = 0;
			while ((len = fis.read(in)) != -1) {
				os.write(in, 0, len);
			}
			s.shutdownOutput();
		}

	}

	@SuppressWarnings("unchecked")
	public void viewallimg() throws UnknownHostException, IOException,
			ClassNotFoundException, SQLException {

		ArrayList<Img> imgs = new ArrayList<Img>();
		String sql = "select * from img ";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while (rs.next()) {
			imgs.add(new Img(rs.getInt(1), rs.getString(2), rs.getString(3), rs
					.getString(4), rs.getString(5)));
		}
		oos.writeObject(imgs);
		oos.flush();
	}

	public static void main(String[] args) {
		try {
			new Server();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
		while (true) {
			s = ss.accept();
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			int command = ois.readInt();
			if (command == LOGIN) {
				this.login();
			}
			if (command == UPLOAD) {
				// this.u_login();
				this.upload();
			}
			if (command == DOWNLOAD) {
				// this.u_login();
				this.download();
			}
			if (command == VIEWALLIMG) {
				// this.u_login();
				this.viewallimg();
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
