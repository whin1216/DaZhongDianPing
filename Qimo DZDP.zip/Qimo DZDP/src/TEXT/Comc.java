package TEXT;

public class Comc {
	String Comc_content;
	String Comc_nature;
	String Comc_ctype;
	int Comc_Cid;
	String Comc_price;
	int Comc_score;

	public Comc(String comcContent, String comcNature, String comcCtype,
			int comcCid, String comcPrice, int comcScore) {
		super();
		Comc_content = comcContent;
		Comc_nature = comcNature;
		Comc_ctype = comcCtype;
		Comc_Cid = comcCid;
		Comc_price = comcPrice;
		Comc_score = comcScore;
	}

	public String getComc_content() {
		return Comc_content;
	}

	public void setComc_content(String comcContent) {
		Comc_content = comcContent;
	}

	public String getComc_nature() {
		return Comc_nature;
	}

	public void setComc_nature(String comcNature) {
		Comc_nature = comcNature;
	}

	public String getComc_ctype() {
		return Comc_ctype;
	}

	public void setComc_ctype(String comcCtype) {
		Comc_ctype = comcCtype;
	}

	public int getComc_Cid() {
		return Comc_Cid;
	}

	public void setComc_Cid(int comcCid) {
		Comc_Cid = comcCid;
	}

	public String getComc_price() {
		return Comc_price;
	}

	public void setComc_price(String comcPrice) {
		Comc_price = comcPrice;
	}

	public int getComc_score() {
		return Comc_score;
	}

	public void setComc_score(int comcScore) {
		Comc_score = comcScore;
	}
}
