package TEXT;
//��Ħ/����
public class Massage extends Store {

	public Massage(String coms, String comsStype) {
		super(coms, comsStype);
		// TODO Auto-generated constructor stub
	}

}
