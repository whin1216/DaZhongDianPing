package TEXT;
//�ư�
public class Bar extends Store {

	public Bar(String coms, String comsStype) {
		super(coms, comsStype);
		// TODO Auto-generated constructor stub
	}

}
