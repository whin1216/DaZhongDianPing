package TEXT;
//��������
public class Entertainment extends Store {

	public Entertainment(String coms, String coms_Stype) {
	 super(coms,coms_Stype);
		// TODO Auto-generated constructor stub
	}

}
