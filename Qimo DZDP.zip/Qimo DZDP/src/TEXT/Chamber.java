package TEXT;
//����
public class Chamber extends Store {

	public Chamber(String coms, String comsStype) {
		super(coms, comsStype);
		// TODO Auto-generated constructor stub
	}

}
