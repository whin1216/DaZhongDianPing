package TEXT;
//���
public class Teahouse extends Store{

	public Teahouse(String coms, String comsStype) {
		super(coms, comsStype);
		// TODO Auto-generated constructor stub
	}

}
