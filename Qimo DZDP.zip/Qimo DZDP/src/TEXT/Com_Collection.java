package TEXT;
//shangpin collection
public class Com_Collection {
    String   Coc_stype;
    int Coc_sID;
    int Co_Cid;
    int Coc_Uid;
	public Com_Collection(String cocStype, int cocSID, int coCid, int cocUid) {
		super();
		Coc_stype = cocStype;
		Coc_sID = cocSID;
		Co_Cid = coCid;
		Coc_Uid = cocUid;
	}
	public String getCoc_stype() {
		return Coc_stype;
	}
	public void setCoc_stype(String cocStype) {
		Coc_stype = cocStype;
	}
	public int getCoc_sID() {
		return Coc_sID;
	}
	public void setCoc_sID(int cocSID) {
		Coc_sID = cocSID;
	}
	public int getCo_Cid() {
		return Co_Cid;
	}
	public void setCo_Cid(int coCid) {
		Co_Cid = coCid;
	}
	public int getCoc_Uid() {
		return Coc_Uid;
	}
	public void setCoc_Uid(int cocUid) {
		Coc_Uid = cocUid;
	}
}
