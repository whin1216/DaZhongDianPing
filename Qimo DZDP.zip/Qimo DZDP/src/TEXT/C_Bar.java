package TEXT;

public class C_Bar extends Commodity {

	public C_Bar(String cainame, int price, String comc) {
		super(cainame, price, comc);
		// TODO Auto-generated constructor stub
	}

	

}
