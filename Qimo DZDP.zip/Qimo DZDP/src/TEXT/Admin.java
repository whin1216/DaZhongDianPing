package TEXT;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import server.DataConnect;


//管理员界面
public class Admin{
   
	private String name;
	private String pw;
	public Admin(String name, String pw) {
		super();
		this.name = name;
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

public static Admin login(String name, String pw) throws SQLException, ClassNotFoundException {
		Admin a = null;
		String sql = "select * from admin where name='"+name+"' and pw = '"+pw+"'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			a = new Admin(name,pw);
		}
		return a;
		

	}

	//管理员登陆
	public void deleteUser(int uid)throws SQLException, ClassNotFoundException {
		String sql ="delete from user where uid ="+uid;
		DataConnect.getStat().executeUpdate(sql);
	}//刪除用戶
	public void deleteMerchant(int mid)throws SQLException, ClassNotFoundException {
		String sql ="delete from user where mid ="+mid;
		DataConnect.getStat().executeUpdate(sql);
	}//刪除商家
	public void addUser(User u) throws SQLException, ClassNotFoundException {
		String sql ="insert into user (name,upw) values ('"+
		u.getName()+"','"+u.getUpw()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}//添加普通用户
	public void addMerchant(Merchant u) throws SQLException, ClassNotFoundException {
		String sql ="insert into Merchant (mid,pw) values ('"+
		u.getMid()+"','"+u.getPw()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}//添加商家
	public void updateUser(User u)throws SQLException, ClassNotFoundException {
		String sql ="update user set name='"+u.getName()+"' , upw = '"
		+u.getUpw()+"' where name ="+u.getName();
		System.out.println(sql);
		DataConnect.getStat().executeUpdate(sql);
	}//更新用户信息
	public void updateMerchant(Merchant u)throws SQLException, ClassNotFoundException {
		String sql ="update Merchant set mid='"+u.getMid()+"' , mpassword= '"
		+u.getPw()+"' where mid ="+u.getMid();
		System.out.println(sql);
		DataConnect.getStat().executeUpdate(sql);
	}//更新商家信息
	
	
	public void deleteComc(int Comc_Cid) throws SQLException, ClassNotFoundException {
		String sql ="delete from comc where Comc_Cid ="+Comc_Cid;
		DataConnect.getStat().executeUpdate(sql);
	}//删除评论
	public void deleteCommodity(int  C_sID) throws SQLException, ClassNotFoundException {
		String sql ="delete from comc where  C_sID ="+ C_sID;
		DataConnect.getStat().executeUpdate(sql);
	}//下架商家的商品
    public void Admin(){
    	
    }
}
