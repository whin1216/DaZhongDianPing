package TEXT;

public class C_KTV extends Commodity{

	public C_KTV(String cainame, int price, String comc) {
		super(cainame, price, comc);
		// TODO Auto-generated constructor stub
	}

	

}
