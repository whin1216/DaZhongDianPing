package TEXT;
//����
public class Fitness extends Store{

	public Fitness(String coms, String comsStype) {
		super(coms, comsStype);
		// TODO Auto-generated constructor stub
	}

}
