package TEXT;

public class C_chamber extends Commodity {

	public C_chamber(String cainame, int price, String comc) {
		super(cainame, price, comc);
		// TODO Auto-generated constructor stub
	}

}
