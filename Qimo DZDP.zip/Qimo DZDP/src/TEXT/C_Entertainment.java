package TEXT;

public class C_Entertainment extends Commodity {

	public C_Entertainment(String cainame, int price, String comc) {
		super(cainame, price, comc);
		// TODO Auto-generated constructor stub
	}

	


	
}
