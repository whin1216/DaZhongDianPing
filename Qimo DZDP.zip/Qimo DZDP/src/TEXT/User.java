package TEXT;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import server.DataConnect;



//用户界面
public class User {
	String upw;
	String name;
	int uid;
public User(String upw, String name, int uid) {
		super();
		this.upw = upw;
		this.name = name;
		this.uid = uid;
	}

public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
public User(String name, String upw) {
		super();
		this.name = name;
		this.upw = upw;
	}
public User(int uid, String name, String upw) {
	super();
	this.uid = uid;
	this.name = name;
	this.upw = upw;
}
public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


	public String getUpw() {
		return upw;
	}
	public void setUpw(String upw) {
		this.upw = upw;
	}

	public static User login(String name, String upw) throws SQLException, ClassNotFoundException {
		User b = null;
		String sql = "select * from user where name='"+name+"' and upw = '"+upw+"'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			b = new User(name,upw);
		}
		return b;
		

	}

//用户登陆
	//public ArrayList<User> searchUser(String name) throws SQLException, ClassNotFoundException {
		//ArrayList<User> users= new ArrayList<User>();
		//String sql = "select * from user where name like '%"+name+"%'";
		//ResultSet rs = DataConnect.getStat().executeQuery(sql);
		//while(rs.next()){
		//	users.add(new User(rs.getString("name"),rs.getString(2)));
		//}
		//return users;
	//}

	public void deleteComc(int Comc_Cid) throws SQLException, ClassNotFoundException {
		String sql ="delete from comc where Comc_Cid ="+Comc_Cid;
		DataConnect.getStat().executeUpdate(sql);
	}//删除评论
	
	public void addCom_Collection(Com_Collection u) throws SQLException, ClassNotFoundException {
		String sql ="insert into Com_Collection (Co_Cid,Coc_sID) values ('"+
		u.getCo_Cid()+"','"+u.getCoc_sID()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}//添加商品收藏
	public void addS_Collection(S_Collection u) throws SQLException, ClassNotFoundException {
		String sql ="insert into Com_Collection (Cos_stype,Coc_sID) values ('"+
		u. Cos_stype()+"','"+u.getCos_sID()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}//添加店鋪收藏
	
	public void addUser(User a) throws SQLException, ClassNotFoundException {
		String sql ="insert into user (name,upw) values ('"+
		a.getName()+"','"+a.getUpw()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}//用戶注冊
	public void addMerchant(Merchant u) throws SQLException, ClassNotFoundException {
		String sql ="insert into Merchant (mid,mpassword) values ('"+
		u.getMid()+"','"+u.getPw()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}//用戶注冊為商家
}
	

	