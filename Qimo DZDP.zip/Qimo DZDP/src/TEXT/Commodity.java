package TEXT;

//商品界面
public class Commodity {
	private String Cainame;// ��Ʒ���
	private int price;// ��Ʒ�۸�
	private String Comc;// ��Ʒ����
    int  C_sID;
	public Commodity(int cSID) {
		super();
		C_sID = cSID;
	}

	public int getC_sID() {
		return C_sID;
	}

	public void setC_sID(int cSID) {
		C_sID = cSID;
	}

	public Commodity(String cainame, int price, String comc) {
		super();
		Cainame = cainame;
		this.price = price;
	     Comc = comc;
	}

	public String getComc() {
		return Comc;
	}

	public void setComc(String comc) {
		Comc = comc;
	}

	public Commodity(String comc) {
		super();
		Comc = comc;
	}

	public void Caiping() {

	}

	public String getCainame() {
		return Cainame;
	}

	public void setCainame(String cainame) {
		Cainame = cainame;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}