package TEXT;

public class C_Massage extends Commodity {

	public C_Massage(String cainame, int price, String comc) {
		super(cainame, price, comc);
		// TODO Auto-generated constructor stub
	}

	

}
