package TEXT;

import java.sql.ResultSet;
import java.sql.SQLException;

import server.DataConnect;
//商家界面
public class Merchant  {
	 String mid;
	 String pw;
	 int id;
	
	
	public Merchant(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void addCommodity (Commodity u) throws SQLException, ClassNotFoundException {
		String sql ="insert into Com_Collection (Cainame,Price) values ('"+
		u.getCainame()+"','"+u.getPrice()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}//上新的商品
    
public static  Merchant login(String mid, String pw) throws SQLException, ClassNotFoundException {
		
		Merchant u = null;
		String sql = "select * from Merchant where mid='"+mid+"' and pw = '"+pw+"'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			u = new Merchant(mid,pw);
		}
		return u;
		
	}
//商家登陸
	public void deleteCommodity(int  C_sID) throws SQLException, ClassNotFoundException {
		String sql ="delete from comc where  C_sID ="+ C_sID;
		DataConnect.getStat().executeUpdate(sql);
	}//商家下架商品
	public void addMerchant(Merchant u) throws SQLException, ClassNotFoundException {
		String sql ="insert into Merchant (mid,pw) values ('"+
		u.getMid()+"','"+u.getPw()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}//商家注冊
	public void updateCommodity(Commodity u)throws SQLException, ClassNotFoundException {
		String sql ="update user set C_sID='"+u.getC_sID()+"' , price = '"
		+u.getPrice()+"' where Cainame ="+u.getCainame();
		System.out.println(sql);
		DataConnect.getStat().executeUpdate(sql);
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public Merchant(String mid, String pw) {
		super();
		this.mid = mid;
		this.pw = pw;
	}

	public Merchant(int id, String Mid, String pw) {
		// TODO Auto-generated constructor stub
		super();
		this.id = id;
		this.mid = mid;
		this.pw = pw;
	}
}
	
	