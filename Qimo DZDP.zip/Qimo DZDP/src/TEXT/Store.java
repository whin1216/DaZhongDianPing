package TEXT;

public class Store {
	String coms;
	String Coms_stype;

	public Store(String coms, String coms_Stype) {
		super();
		this.coms = coms;
		Coms_stype = coms_Stype;
	}
   


	public String getComs() {
		return coms;
	}

	public void setComs(String coms) {
		this.coms = coms;
	}

	public String getComs_stype() {
		return Coms_stype;
	}

	public void setComs_stype(String comsStype) {
		Coms_stype = comsStype;
	}

}
