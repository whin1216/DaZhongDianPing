package TEXT;

public class C_Teahouse extends Commodity {

	public C_Teahouse(String cainame, int price, String comc) {
		super(cainame, price, comc);
		// TODO Auto-generated constructor stub
	}

	
}
