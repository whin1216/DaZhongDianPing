package TEXT;

public class KTV extends Store {

	public KTV(String coms, String comsStype) {
		super(coms, comsStype);
		// TODO Auto-generated constructor stub
	}

}
