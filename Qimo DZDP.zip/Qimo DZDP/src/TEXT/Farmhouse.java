package TEXT;
//ũ����
public class Farmhouse extends Store{

	public Farmhouse(String coms, String comsStype) {
		super(coms, comsStype);
		// TODO Auto-generated constructor stub
	}

}
