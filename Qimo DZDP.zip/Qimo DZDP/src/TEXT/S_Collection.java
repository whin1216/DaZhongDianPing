package TEXT;

public class S_Collection {
	String  Cos_stype;
	int Cos_sID;
	int Cos_Uid;
	public String getS_Collection() {
		return  Cos_stype;
	}
	public void setS_Collection(String cosstype) {
		 Cos_stype =  cosstype;
	}
	public int getCos_sID() {
		return Cos_sID;
	}
	public void setCos_sID(int cosSID) {
		Cos_sID = cosSID;
	}
	public int getCos_Uid() {
		return Cos_Uid;
	}
	public void setCos_Uid(int cosUid) {
		Cos_Uid = cosUid;
	}
	public S_Collection(String  cosstype, int cosSID, int cosUid) {
		super();
		 Cos_stype =  cosstype;
		Cos_sID = cosSID;
		Cos_Uid = cosUid;
	}
	public String Cos_stype() {
		// TODO Auto-generated method stub
		return null;
	}

}
