package TEXT;

public class ImgUtils {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static String getImgSuffix(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getImgName() {
		// TODO Auto-generated method stub
		return null;
	}

}
