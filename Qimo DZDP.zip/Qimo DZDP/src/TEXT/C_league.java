package TEXT;

public class C_league extends Commodity {

	public C_league(String cainame, int price, String comc) {
		super(cainame, price, comc);
		// TODO Auto-generated constructor stub
	}

}
