package TEXT;
//ϴԡ
public class Bath extends Store{

	public Bath(String coms, String comsStype) {
		super(coms, comsStype);
		// TODO Auto-generated constructor stub
	}

}
