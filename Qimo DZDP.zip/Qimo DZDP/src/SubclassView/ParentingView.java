/*
 * ParentingView.java
 *
 * Created on __DATE__, __TIME__
 */

package SubclassView;

import GNView.MainView;

/**
 *
 * @author  __USER__
 */
@SuppressWarnings("serial")
public class ParentingView extends javax.swing.JFrame {

	/** Creates new form ParentingView */
	public ParentingView() {
		initComponents();
		this.setLocationRelativeTo(null);
		this.setResizable(false);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jButton17 = new javax.swing.JButton();
		jComboBox1 = new javax.swing.JComboBox();
		jButton4 = new javax.swing.JButton();
		jButton1 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jButton9 = new javax.swing.JButton();
		jButton13 = new javax.swing.JButton();
		jLabel2 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jButton7 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton10 = new javax.swing.JButton();
		jButton14 = new javax.swing.JButton();
		jButton15 = new javax.swing.JButton();
		jButton11 = new javax.swing.JButton();
		jLabel5 = new javax.swing.JLabel();
		jButton6 = new javax.swing.JButton();
		jLabel4 = new javax.swing.JLabel();
		jButton5 = new javax.swing.JButton();
		jButton12 = new javax.swing.JButton();
		jLabel8 = new javax.swing.JLabel();
		jButton2 = new javax.swing.JButton();
		jLabel7 = new javax.swing.JLabel();
		jButton8 = new javax.swing.JButton();
		jButton16 = new javax.swing.JButton();
		jButton18 = new javax.swing.JButton();
		jButton19 = new javax.swing.JButton();
		jLabel9 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jButton17.setText("\u8fd4\u56de");
		jButton17.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton17ActionPerformed(evt);
			}
		});

		jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(
				new String[] { "��ͯ��԰", "��ͯ��Ӱ", "�������", "������Ӿ", "�ٶ�����", "��������",
						"�ٶ�Ӣ��", "ĸӤ����" }));
		jComboBox1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboBox1ActionPerformed(evt);
			}
		});

		jButton4.setText("\u56fe\u7247");

		jButton1.setText("\u56fe\u7247");

		jLabel1.setText("Poro\u4e3b\u9898\u4e50\u56ed");

		jLabel3.setText("\u6d77\u6d0b\u738b\u56fd");

		jButton9.setText("\u8bc4\u5206\uff1a7.7");

		jButton13.setText("\u8bc4\u5206\uff1a9.9");

		jLabel2.setText("\u732a\u732a\u4fa0\u4e3b\u9898\u4e50\u56ed");

		jLabel6.setText("\u5149\u5934\u5f3a\u4e3b\u9898\u4e50\u56ed");

		jButton7.setText("\u56fe\u7247");

		jButton3.setText("\u56fe\u7247");

		jButton10.setText("\u8bc4\u5206\uff1a7.5");

		jButton14.setText("\u8bc4\u5206\uff1a9.5");

		jButton15.setText("\u8bc4\u5206\uff1a7.5");

		jButton11.setText("\u8bc4\u5206\uff1a9.0");

		jLabel5.setText("\u51b0\u96ea\u738b\u56fd\u4e3b\u9898\u4e50\u56ed");

		jButton6.setText("\u56fe\u7247");

		jLabel4.setText("\u559c\u7f8a\u7f8a\u4e3b\u9898\u4e50\u56ed");

		jButton5.setText("\u56fe\u7247");

		jButton12.setText("\u8bc4\u5206\uff1a6.5");

		jLabel8.setText("\u661f\u671f8\u513f\u7ae5\u5c0f\u9547");

		jButton2.setText("\u56fe\u7247");

		jLabel7.setText("\u513f\u7ae5\u516c\u56ed");

		jButton8.setText("\u56fe\u7247");

		jButton16.setText("\u8bc4\u5206\uff1a9.0");

		jButton18.setText("\u4e0a\u4e00\u9875");

		jButton19.setText("\u4e0b\u4e00\u9875");

		jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel9.setText("\u4eb2\u5b50");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jButton17,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																102,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jComboBox1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																102,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				18,
																				18,
																				18)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING,
																																false)
																														.addComponent(
																																jButton4,
																																javax.swing.GroupLayout.Alignment.LEADING,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																141,
																																Short.MAX_VALUE)
																														.addComponent(
																																jButton1,
																																javax.swing.GroupLayout.Alignment.LEADING,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																141,
																																Short.MAX_VALUE)
																														.addComponent(
																																jLabel1,
																																javax.swing.GroupLayout.Alignment.LEADING,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																Short.MAX_VALUE)
																														.addComponent(
																																jLabel3,
																																javax.swing.GroupLayout.Alignment.LEADING,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																141,
																																Short.MAX_VALUE)
																														.addComponent(
																																jButton9,
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jButton13,
																																javax.swing.GroupLayout.Alignment.LEADING))
																										.addGap(
																												38,
																												38,
																												38)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addGroup(
																																jPanel1Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING,
																																				false)
																																		.addComponent(
																																				jLabel2,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				Short.MAX_VALUE)
																																		.addComponent(
																																				jLabel6,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				Short.MAX_VALUE)
																																		.addComponent(
																																				jButton7,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				141,
																																				Short.MAX_VALUE)
																																		.addComponent(
																																				jButton3,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				141,
																																				javax.swing.GroupLayout.PREFERRED_SIZE))
																														.addComponent(
																																jButton10)
																														.addComponent(
																																jButton14))
																										.addGap(
																												37,
																												37,
																												37)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jButton15)
																														.addComponent(
																																jButton11)
																														.addGroup(
																																jPanel1Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING,
																																				false)
																																		.addGroup(
																																				jPanel1Layout
																																						.createSequentialGroup()
																																						.addGroup(
																																								jPanel1Layout
																																										.createParallelGroup(
																																												javax.swing.GroupLayout.Alignment.LEADING,
																																												false)
																																										.addComponent(
																																												jLabel5,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												Short.MAX_VALUE)
																																										.addComponent(
																																												jButton6,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												141,
																																												javax.swing.GroupLayout.PREFERRED_SIZE))
																																						.addGap(
																																								51,
																																								51,
																																								51)
																																						.addGroup(
																																								jPanel1Layout
																																										.createParallelGroup(
																																												javax.swing.GroupLayout.Alignment.LEADING)
																																										.addComponent(
																																												jLabel4,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												128,
																																												Short.MAX_VALUE)
																																										.addComponent(
																																												jButton5,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												141,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)
																																										.addComponent(
																																												jButton12)))
																																		.addGroup(
																																				jPanel1Layout
																																						.createSequentialGroup()
																																						.addGroup(
																																								jPanel1Layout
																																										.createParallelGroup(
																																												javax.swing.GroupLayout.Alignment.LEADING,
																																												false)
																																										.addComponent(
																																												jLabel8,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												Short.MAX_VALUE)
																																										.addComponent(
																																												jButton2,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												141,
																																												javax.swing.GroupLayout.PREFERRED_SIZE))
																																						.addPreferredGap(
																																								javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																																								51,
																																								Short.MAX_VALUE)
																																						.addGroup(
																																								jPanel1Layout
																																										.createParallelGroup(
																																												javax.swing.GroupLayout.Alignment.TRAILING,
																																												false)
																																										.addComponent(
																																												jLabel7,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												Short.MAX_VALUE)
																																										.addComponent(
																																												jButton8,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												141,
																																												Short.MAX_VALUE)
																																										.addComponent(
																																												jButton16,
																																												javax.swing.GroupLayout.Alignment.LEADING))))))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jButton18)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jButton19))))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				332,
																				332,
																				332)
																		.addComponent(
																				jLabel9)))
										.addContainerGap(111, Short.MAX_VALUE)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGap(28, 28, 28)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel9)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton1,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								114,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jButton7,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								114,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jButton6,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								114,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jButton5,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								114,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabel1)
																						.addComponent(
																								jLabel4)
																						.addComponent(
																								jLabel6)
																						.addComponent(
																								jLabel5))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton9)
																						.addComponent(
																								jButton10)
																						.addComponent(
																								jButton11)
																						.addComponent(
																								jButton12))
																		.addGap(
																				52,
																				52,
																				52)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton4,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								114,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jButton3,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								114,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jButton2,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								114,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jButton8,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								114,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.BASELINE)
																										.addComponent(
																												jLabel3)
																										.addComponent(
																												jLabel2)
																										.addComponent(
																												jLabel8))
																						.addComponent(
																								jLabel7))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jButton13)
																						.addComponent(
																								jButton14)
																						.addComponent(
																								jButton15)
																						.addComponent(
																								jButton16)))
														.addComponent(
																jComboBox1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												75, Short.MAX_VALUE)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jButton18)
														.addComponent(jButton19)
														.addComponent(jButton17))
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {
		new MainView().setVisible(true);
		this.dispose();
	}

	private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		try {
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
		} catch (Exception e) {
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new BeautyView().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton10;
	private javax.swing.JButton jButton11;
	private javax.swing.JButton jButton12;
	private javax.swing.JButton jButton13;
	private javax.swing.JButton jButton14;
	private javax.swing.JButton jButton15;
	private javax.swing.JButton jButton16;
	private javax.swing.JButton jButton17;
	private javax.swing.JButton jButton18;
	private javax.swing.JButton jButton19;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JButton jButton9;
	private javax.swing.JComboBox jComboBox1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	// End of variables declaration//GEN-END:variables

}